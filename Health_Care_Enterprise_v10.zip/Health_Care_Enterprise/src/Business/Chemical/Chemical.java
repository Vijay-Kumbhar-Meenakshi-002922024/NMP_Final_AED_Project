/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Chemical;

/**
 *
 * @author vgout
 */
public class Chemical {
    private String chemicalName;
    
    
     
    
   

    public String getChemicalName() {
        return chemicalName;
    }

    public void setChemicalName(String chemicalName) {
        this.chemicalName = chemicalName;
    }

  

   
    
    
}
