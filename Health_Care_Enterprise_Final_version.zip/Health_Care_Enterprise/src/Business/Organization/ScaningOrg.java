/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.Organization;

import Business.ScaningInventory.scaning;
import Business.Role.ScaningRole;
import Business.Role.Role;
import Business.ScaningInventory.scaninglist;
import java.util.ArrayList;
/**
 *
 * @author dpsmv
 */
public class ScaningOrg extends Organization{
private ArrayList<scaning> SCANLIST;
    public ScaningOrg() {
        super(Organization.Type.Scan.getValue());
             SCANLIST=new ArrayList<scaning>();
   
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList();
        roles.add(new ScaningRole());
        return roles;
    }
      public ArrayList<scaning> getscanList() {
        return SCANLIST;
    }
 public void setscanlist(ArrayList<scaning> SCANLIST) {
        this.SCANLIST = SCANLIST;
    }
    
    public void addscanlist(scaning ci)
    {
       
        SCANLIST.add(ci);
        
    }

    
}
