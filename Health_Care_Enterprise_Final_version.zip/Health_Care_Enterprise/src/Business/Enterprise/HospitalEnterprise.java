/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Organization.Organization;
import Business.Patient.PatientDirectory;

import Business.Role.Role;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dsnik
 */
public class HospitalEnterprise extends Enterprise {
      private PatientDirectory patientDirectory;
    public HospitalEnterprise(String name){
        super(name,EnterpriseType.Hospital);
    }
    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    }
    public List<Organization.Type> getAllOrganizationTypes() {
        List<Organization.Type> orgTypes = new ArrayList<>();
        orgTypes.add(Organization.Type.Doctor);
        orgTypes.add(Organization.Type.HospitalAssistant);
        //orgTypes.add(Organization.Type.Patient);
        //orgTypes.add(Organization.Type.Accountant);

        return orgTypes;
    }
    public String toString() {
        return this.getName();
    }
    
    public PatientDirectory getPatientDirectory() {
        return patientDirectory;
    }

    public void setPatientDirectory(PatientDirectory patientDirectory) {
        this.patientDirectory = patientDirectory;
    
    }
    
}
