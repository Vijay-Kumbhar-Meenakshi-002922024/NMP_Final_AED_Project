/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.WorkQueue;

/**
 *
 * @author dsnik
 */
public class ScaningRequest extends WorkRequest{
    
   
private int status_id;
private String status;
    private String scanName;
    
    private String deliveryTime;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

  
    
    public String getDeliveryTime() {
        return deliveryTime;
    }

   

    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public int getStatus_id() {
        return status_id;
    }

    public String getScanName() {
        return scanName;
    }

    public void setStatus_id(int status_id) {
        this.status_id = status_id;
    }

    public void setScanName(String scanName) {
        this.scanName = scanName;
    }
    
     @Override
    public String toString() {
        return scanName;
    }
}
