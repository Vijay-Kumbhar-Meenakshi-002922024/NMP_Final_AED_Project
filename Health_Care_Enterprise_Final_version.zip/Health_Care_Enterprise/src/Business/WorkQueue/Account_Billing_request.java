/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.WorkQueue;
import Business.Patient.Patient;
/**
 *
 * @author dsnik
 */
public class Account_Billing_request extends WorkRequest {

    private String billingAmount;

    private boolean hasInsurance;
    private boolean isInsuranceClaimSettled;

    Patient patient;

    public String getBillingAmount() {
        return billingAmount;
    }

    public void setBillingAmount(String billingAmount) {
        this.billingAmount = billingAmount;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public boolean isHasInsurance() {
        return hasInsurance;
    }

    public void setHasInsurance(boolean hasInsurance) {
        this.hasInsurance = hasInsurance;
    }

    public boolean isIsInsuranceClaimSettled() {
        return isInsuranceClaimSettled;
    }

    public void setIsInsuranceClaimSettled(boolean isInsuranceClaimSettled) {
        this.isInsuranceClaimSettled = isInsuranceClaimSettled;
    }

    @Override
    public String toString() {
        return String.valueOf(billingAmount);
    }
}
